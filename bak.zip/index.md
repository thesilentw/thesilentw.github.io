---
layout: default
title: this is the page title
---

# here is h1 text
## this is h2
### this is h3 text here
#### h4 is smaller
##### h5 smaller still
###### h6 is REALLY small

**At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident,** similique sunt in culpa qui officia deserunt *mollitia animi, id est laborum et dolorum fuga.*

## here's more h2 text
***At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga.*** Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil `impedit quo minus id quod maxime` placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat.

> using markdown
> using
> mfw
> 
> :(
> > blockquotes can be nested

---
a horizontal rule appears above here
and another below
***

### this is h3 text
* these are list items
* item 2
* item 3

1. a thing
2. another
3. another again

